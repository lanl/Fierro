This code is the fruit of Kate Morley's labor, taken from here:

- http://code.iamkate.com/javascript/collapsible-lists/

She includes a generous CC0 1.0 license for all materials on her site:

- http://code.iamkate.com/
