#ifndef ELEMENTS_UTILITIES_H
#define ELEMENTS_UTILITIES_H 



namespace utils{

	using real_t = double;
}

#endif // ELEMENTS_UTILITIES_H
